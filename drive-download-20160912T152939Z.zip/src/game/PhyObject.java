package game;

import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;

public class PhyObject implements Serializable{
	/*
	 * for now simple collision not proper collision solving just preventing intersection
	 */
	public Vec3 vel=new Vec3(0,0,0);
	public boolean dynamic=false;
	public Vec3 worldPos=new Vec3(0,0,0);
	public MeshCollider collider;
	public Mesh mesh=new Mesh();
	public PhyObject(Vec3 pos){
		mesh=new Mesh();
		this.collider=new MeshCollider();
		worldPos=pos;
		this.collider.worldPos=this.worldPos;
	}
	public PhyObject(){
		this.collider=new MeshCollider();
		mesh=new Mesh();
	}
	public void updatePos(){
		this.collider.worldPos=this.worldPos;
	}
	public Vec3[][] getTris(){
		Vec3[][] tranTris= this.mesh.getTris();
		
		for (int i = 0; i < tranTris.length; i++) {
			for (int m = 0; m < 3; m++) {
			tranTris[i][m].translate(this.worldPos);
			
			}
		}
		return tranTris;
	}
	public void move(int steps,ArrayList<PhyObject> collisionObjects){
		this.collider.worldPos=this.worldPos;
		ArrayList<PhyObject> futureObjects=new ArrayList<PhyObject>();
		if(this.dynamic){
			this.vel.y-=0.1;
		}
	}
}
