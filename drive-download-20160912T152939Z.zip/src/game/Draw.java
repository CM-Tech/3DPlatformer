package game;
import java.awt.*;

import java.awt.event.*;
import java.io.*;

import javax.swing.*;
import java.util.*;
import java.util.Timer;
public class Draw implements Serializable{
	
	static final long serialVersionUID = -7298352464830308761L;
	boolean keyDown = false;
	float mul = 1;
	public int score = 0;
	public Vec3 camRot=new Vec3(-45,0,0);
	public Vec3 camPos=new Vec3(0,200,-200);
	public RectangularPrism player=new RectangularPrism(new Vec3(100,100,100));
	public Vec3 playerPos=new Vec3(0,0,0);
	public Vec3 playerVel=new Vec3(0,0,0);
	public static int xRot = 0;
	public static int yRot = 0;
	public static int zRot = 0;
	public static String rotMode = "x";
	public ArrayList<PhyObject> objects = new ArrayList<PhyObject>();
	public static int W = 700;
	public static int H = 700;
	public static int camX = W/2;
	public static int camY = H/2;
	public static int x = 0;
	public static int y = 200;
	public static int z = 0;
	public static final Vec3 CENTER = new Vec3(W/2, H/2, 0);
	public FrameDraw panel;
	public JLabel scoreLabel;
	public static JFrame frame;
	public BoxCollider playerBox;
	public static boolean jump = false;
	public static boolean grounded = false;
	public static boolean toggled = false;
	static int objNum = 8;
	public static float frameRate = 10;
	public static float rate = frameRate/30;
	static boolean[] keys;
	void load(){
		for(int i = 0; i < 1000; i ++){
			keys = new boolean[i];
		}
		playerBox = new BoxCollider(CENTER.add(new Vec3(0, 50, 0)), CENTER.add(new Vec3(1, 50, 1)));
		frame = new JFrame();
		
		scoreLabel = new JLabel(String.valueOf(score));
		scoreLabel.setSize(new Dimension(100, 100));
		scoreLabel.setHorizontalAlignment((int) JLabel.CENTER_ALIGNMENT);
		scoreLabel.setFont(new Font("Arial", 50, 50));
		scoreLabel.setOpaque(true);
		
		panel = new FrameDraw();
		panel.setSize(new Dimension(W, H));
		
		frame.setPreferredSize(new Dimension(W, H + 50));
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.add(scoreLabel, BorderLayout.NORTH);
		frame.add(panel, BorderLayout.CENTER);
		
		(panel).paintComponent(panel.getGraphics());
		
		frame.pack();
		Timer t = new Timer();
		t.schedule(new DoStuff(), 0, (long) frameRate);
	}
	void init(){
		for(int i=objNum-1; i>=0; i--){
			RectangularPrism p = new RectangularPrism(new Vec3(250, 10, 250));
			p.worldPos.translate(new Vec3(0, 200, 500*i));
			objects.add(p);
		}
		load();
	}
	
	@SuppressWarnings("null")
	Draw() {
		init();
	}
	class DoStuff extends TimerTask{
		@Override
		public void run() {
			(panel).repaint();
		}
	}
	
	@SuppressWarnings("unused")
	private static void sleep(int m){
		try{Thread.sleep(m);}catch(Exception e){}
	}
	
	@SuppressWarnings("serial")
	class FrameDraw extends JPanel implements KeyListener{
		public static final long MAX_DIST = 1l;
		FrameDraw(){
			addKeyListener(this);
		}
		protected void paintComponent(Graphics g) {
			update();
			g.clearRect(0, 0, W*2, H*2);
			int[] a1 = {0,4,5,1};
			int[] a2 = {2,0,1,3};
			int[] a3 = {6,7,5,4};
			int[] a4 = {6,7,3,2};
			int[] a5 = {3,7,5,1};
			int[] a6 = {2,6,4,0};
			int[][] arrays = {a1, a2, a3, a4, a5, a6};
			//arrays = sortFaces(arrays);
			
			g.setColor(Color.black);
			for(int j=0; j<objects.size(); j++){
				PhyObject obj = objects.get(j);
				Vec3[][] triArray=obj.mesh.getTris();
				for (int i = 0; i < triArray.length; i++) {
					for (int m = 0; m < 3; m++) {
					Vec3 vec = triArray[i][m];
					drawPoint(vec, g);
					char[] charAr = {Integer.toString(i).charAt(0)};
					Point rP=getRenderPoint(vec);
					g.drawChars(charAr, 0, 1, rP.x, rP.y);
					}
				}
			}
			draw3d(arrays, g);
			
			g.setColor(Color.green);
			drawPlayerPoint(CENTER.add(new Vec3(0, 190, 0)), g, 50);
		}
		private int[][] getArray(ArrayList<Vec3> vecs, int[] array){
			int[][] rArray = new int[2][array.length];
			
			for(int i=0; i<array.length; i++){
				Vec3 vec = (Vec3)(vecs.get(array[i]));
				int x = (int)vec.x;
				int y = (int)vec.y;
				int z = (int)vec.z;
				Point rP=getRenderPoint(vec);
				rArray[0][i] = rP.x;//getX(x, z);
				rArray[1][i] = rP.y;//getY(y, z);
			}
			return rArray;
		}
		
		private void draw3d(int[][] arrays, Graphics g){
			for(int i=0; i<objects.size(); i++){
				PhyObject obj = objects.get(i);
				Vec3[][] triArray=obj.mesh.getTris();
				
				for(int j=0; j<triArray.length; j++){
					//int[] aInt = arrays[j];
					//int[][] aaInt = getArray(obj.mesh, aInt);
					g.setColor(Color.red);
					if(true){//Use Surface normal for shading
					Vec3 V=triArray[j][1].subtract(triArray[j][0]);
					Vec3 W=triArray[j][2].subtract(triArray[j][0]);
					Vec3 normal=new Vec3(V.y*W.z-V.z*W.y,V.z*W.x-V.x*W.z,V.x*W.y-V.y*W.x);
					
					normal=normal.multiply(1.0f/normal.len());
					if(triArray[j][0].add(normal).len()>triArray[j][0].subtract(normal).len()){
						normal=normal.multiply(-1.0f);
					}
					Vec3 light=new Vec3(0f,1f,0f);
					light=light.multiply(1.0f/light.len());
					
					g.setColor(Color.getHSBColor(0, 1, normal.dot(light)));
					}
					int[] xS=new int[3];
					int[] yS=new int[3];
					for(int fI=0;fI<3;fI++){
						Point rp=this.getRenderPoint(triArray[j][fI]);
						xS[fI]=rp.x;
						yS[fI]=rp.y;
					}
					g.fillPolygon(xS,yS, 3);
					g.setColor(Color.black);
					g.drawPolygon(xS,yS, 3);
				}
			}
		}
		private void drawPoint(Vec3 vec, Graphics g){
			Point rP=getRenderPoint(vec);
			g.fillRect(rP.x, rP.y, 5, 5);
		}
		private void drawPlayerPoint(Vec3 vec, Graphics g, int size){
			g.fillRect((int)(vec.x - size/2), (int)(vec.y-size/2), size, size);
		}
		private Point getRenderPoint(Vec3 vec){
			Vec3 transformedVec=camTran(vec.clone());
			
			return new Point(getX(transformedVec.x, transformedVec.z), H-getY(transformedVec.y, transformedVec.z));
		}
		private Vec3 camTran(Vec3 vec){
			Vec3 transformedVec=vec.clone();
			transformedVec=transformedVec.subtract(camPos);
			transformedVec.rotate("x", new Vec3(0, 0,0),camRot.x);
			transformedVec.rotate("y", new Vec3(0, 0,0),camRot.y);
			return transformedVec;
		}
		private int getX(float x, float z){
//			int rInt = (int)(((x-W/2)*MAX_DIST/z)+W/2);
			int average_len = W/2;
			int rInt = (int) (((x-W/2) * ( average_len ) ) / ( z + ( W/2) )) + W/2;

			if(z <= -average_len){
				rInt = (int) (((x-W/2) * ( average_len ) ) / (150)) + W/2;
			}
			return rInt;
		}
		private int getY(float y, float z){
//			int rInt = (int)(((y-H/2)*MAX_DIST/z)+H/2);
			int average_len = H/2;
			y+= 175;
			int rInt = (int) (((y-H/2) * ( average_len) ) / ( z+ ( average_len) )) + H/2;
			if(z <= -average_len){
				rInt=(int) ((y*4)-1450);
			}
			return rInt;
		}
		private Vec3[][] sortFaces(Vec3[][] arrays){
			//PhyObject obj = objects.get(0);
			//Vec3[][] triArray=obj.mesh.getTris();
	
			Float[][] VecsMidZ = new Float[arrays.length][2];
			
			for(int i=0; i<arrays.length; i++){
				Vec3 vec1 = new Vec3(0,0,0);
				vec1.x = ((Vec3)(arrays[i][0])).x;
				vec1.y = ((Vec3)(arrays[i][0])).y;
				vec1.z = ((Vec3)(arrays[i][0])).z;
				Vec3 vec2 = new Vec3(0,0,0);//(Vec3) vecs.get(arrays[i][2]);
				vec2.x = ((Vec3)(arrays[i][1])).x;
				vec2.y = ((Vec3)(arrays[i][1])).y;
				vec2.z = ((Vec3)arrays[i][1]).z;
				Vec3 vec3 = new Vec3(0,0,0);//(Vec3) vecs.get(arrays[i][2]);
				vec2.x = ((Vec3)(arrays[i][2])).x;
				vec2.y = ((Vec3)(arrays[i][2])).y;
				vec2.z = ((Vec3)(arrays[i][2])).z;
				
				
				VecsMidZ[i][0]=camTran(vec1).len();
//				VecsMidZ[i] = ((int) ((Vec3)(vecs.get(iArray[0]))).z);
				VecsMidZ[i][1] = (float) i;
			}
			Arrays.sort(VecsMidZ, new Comparator<Float[]>() {
				@Override
				public int compare(Float[] o1, Float[] o2) {
					if(o1[0] - o2[0]>0){
						return -1;
					}
					if(o1[0] - o2[0]<0){
						return 1;
					}
					return 0;
				}
			});
			//Arrays.sort(VecsMidZ, Collections.reverseOrder());
			@SuppressWarnings("unused")
			
			Vec3[][] temp = new Vec3[arrays.length][3];
			for(int i=0; i<arrays.length; i++){
				for(int j=0; j<3; j++){
					temp[i][j] = arrays[i][j];
				}
			}
//			temp = arrays;
			
			for(int i=0; i<arrays.length; i++){
				int mod = Math.round(VecsMidZ[i][1]);
				arrays[i] = temp[mod];
			}
			
			return arrays;
		}
		public void addNotify() {
	        super.addNotify();
	        requestFocus();
	    }
		
		@Override
		public void keyTyped(KeyEvent e) {

		}
		int keyNum;
		int ticks = 0;
		
		@Override
		public void keyPressed(KeyEvent e) {
			
			keyDown = true;
			keyNum = e.getKeyCode();
			keys[e.getKeyCode()] = true;//pressed
			if(keys[KeyEvent.VK_SPACE] && /*toggled*/ grounded){
				jump=true;
//				BoxCollider.timer.schedule(new setToggled(), 40);
			}
		}
		class setToggled extends TimerTask{
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Draw.toggled = false;
			}
		}
		@Override
		public void keyReleased(KeyEvent e) {
			if(keys[KeyEvent.VK_W] && keyDown){
				ticks = 5;
			}
			keys[e.getKeyCode()] = false;
			
		}
		public void update(){
			if(ticks > 0 && mul == 1){
				ticks -= rate;
			}
			panel.requestFocus();
			//Object3d.addVelocityArray(objects, new Vec3(0, 1, 0).multiply(0.6f*rate));//gravity happens to be 0.32 units be second
			ArrayList left = new ArrayList<Object3d>();
			ArrayList right = new ArrayList<Object3d>();
			for(int i=objects.size()-1; i>=0; i--){
				if(i%2 == 0){
					left.add(objects.get(i));
				}else{
					right.add(objects.get(i));
				}
			}
			//Object3d.setVelocityArrayX(left, 1, 500);
			//Object3d.setVelocityArrayX(right, -1, 500);
			//if(!playerBox.isTouchingArrayGrav(objects)){
				
			//}
			/*for(int i=objects.size()-1; i>=0; i--){
				Object3d obj = objects.get(i);
				if(playerBox.isTouching(obj.boxCollider)){
					if(objects.size() - i+1>score){
						score = objects.size() - i;
						scoreLabel.setText(String.valueOf(score));
					}
					if(score == objects.size()){
						scoreLabel.setText("YOU WIN!!!");
					}
				}
			}*/
			//Object3d.updateArray(objects);
			mul = 1;
			if(keys[KeyEvent.VK_SHIFT] || keys[KeyEvent.VK_W] && ticks > 0 || keys[KeyEvent.VK_R]){
				mul = 2;
			}
			mul*=rate;
			if(keys[KeyEvent.VK_W] && keyDown){
				//Object3d.translateArray(objects, Vec3.FORWARD.multiply(10*mul));
				camPos.z-= 10;
				playerPos.z -= 10;
			} if(keys[KeyEvent.VK_S] && keyDown){
				//Object3d.translateArray(objects, Vec3.BACKWARD.multiply(10*mul));
				camPos.z+= 10;
				playerPos.z += 10;
			} if(keys[KeyEvent.VK_A] && keyDown){
				//Object3d.translateArray(objects, Vec3.LEFT.multiply(10*mul));
				camPos.x-= 10;
				playerPos.x-= 10;
			} if(keys[KeyEvent.VK_D] && keyDown){
				//Object3d.translateArray(objects, Vec3.RIGHT.multiply(10*mul));
				camPos.x+= 10;
				playerPos.x += 10;
			} if(keys[KeyEvent.VK_SPACE] && keyDown && /*toggled*/ grounded){
				Vec3 jumpVec = new Vec3(0, 5, 0);
				
				//Object3d.addVelocityArray(objects, jumpVec.multiply(rate));
			}
			if(keys[KeyEvent.VK_M]){
				Main.save();
			}
			if(keys[KeyEvent.VK_L]){
				Main.load();
			}
			if(keys[KeyEvent.VK_R]){
				Main.restart();
			}
//			System.out.println(y);
		}
	}
}
