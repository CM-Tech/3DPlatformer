package game;

import java.util.ArrayList;

public class RectangularPrism extends PhyObject {
	
	public RectangularPrism(Vec3 dim) {
		super();
		Vec3 a=dim.multiply(new Vec3(-1,1,-1)).multiply(0.5f);
		Vec3 b=dim.multiply(new Vec3(1,1,-1)).multiply(0.5f);
		Vec3 c=dim.multiply(new Vec3(1,1,1)).multiply(0.5f);
		Vec3 d=dim.multiply(new Vec3(-1,1,1)).multiply(0.5f);
		//top
		this.mesh.addTri(a,b,c);
		this.mesh.addTri(c,d,a);
		a.rotate("x", Vec3.ZERO, 90);
		b.rotate("x", Vec3.ZERO, 90);
		c.rotate("x", Vec3.ZERO, 90);
		d.rotate("x", Vec3.ZERO, 90);
		this.mesh.addTri(a,b,c);
		this.mesh.addTri(c,d,a);
		a.rotate("x", Vec3.ZERO, 90);
		b.rotate("x", Vec3.ZERO, 90);
		c.rotate("x", Vec3.ZERO, 90);
		d.rotate("x", Vec3.ZERO, 90);
		this.mesh.addTri(a,b,c);
		this.mesh.addTri(c,d,a);
		a.rotate("x", Vec3.ZERO, 90);
		b.rotate("x", Vec3.ZERO, 90);
		c.rotate("x", Vec3.ZERO, 90);
		d.rotate("x", Vec3.ZERO, 90);
		this.mesh.addTri(a,b,c);
		this.mesh.addTri(c,d,a);
		
		a.rotate("y", Vec3.ZERO, 90);
		b.rotate("y", Vec3.ZERO, 90);
		c.rotate("y", Vec3.ZERO, 90);
		d.rotate("y", Vec3.ZERO, 90);
		this.mesh.addTri(a,b,c);
		this.mesh.addTri(c,d,a);
		
		a.rotate("y", Vec3.ZERO, 180);
		b.rotate("y", Vec3.ZERO, 180);
		c.rotate("y", Vec3.ZERO, 180);
		d.rotate("y", Vec3.ZERO, 180);
		this.mesh.addTri(a,b,c);
		this.mesh.addTri(c,d,a);
		this.collider.mesh.triArray=this.mesh.triArray.clone();
		
		
		// TODO Auto-generated constructor stub
	}

}
